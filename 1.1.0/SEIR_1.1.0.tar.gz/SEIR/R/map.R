#' @title somedata to test
#'
#' @description a data contain map information
#'
#' @docType data
#' @name map
#' @keywords datasets
#' @usage data(map)

#' @format A dataframe containing SNP bp pos information
NULL
