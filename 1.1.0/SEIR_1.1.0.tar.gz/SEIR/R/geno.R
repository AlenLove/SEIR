#' @title somedata to test
#'
#' @description Numeric format of genotype dataset
#'
#' @docType data
#' @name geno
#' @keywords  genotype datasets
#' @usage data(geno)
#' @format A matrix containing genotype information
NULL
