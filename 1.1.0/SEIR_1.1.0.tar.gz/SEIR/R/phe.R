#' @title somedata to test
#'
#' @description a data contain phenotype information
#'
#' @docType data
#' @name phe
#' @keywords datasets
#' @usage data(phe)

#' @format A dataframe containing one phenotype 
NULL
